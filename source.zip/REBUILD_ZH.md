# 从源码编译 ALG05

源码位于 sloop-source/；sdk-minimal/ 保留上一测试包相同的 SDK 构建部件及许可证。
设置 JIELI_TOOLCHAIN 为工具链目录，AC79_SDK 为 sdk-minimal 的绝对路径，在 sloop-source 执行 sh build.sh。
工具链获取说明见源码 BUILDING.md 与 tools/get_toolchain.sh。
运行 AC79_SDK=... sh tests/run_tests.sh 验证，生成网站用 python3 web/make_site.py build/felucca.fwsc ALG05-TEST build/github-pages。
开发时需要解压 source.zip；部署网页时不用解压它。
