#define FELUCCA_FLASH 0
/* SPDX-License-Identifier: GPL-3.0-only */
/* The real UI (ui.c, ui_draw.c, ui_studio.c, ui_layers.c, ui_song.c, ui_menu.c, ui_input.c) on a
 * framebuffer with panel / flash / storage doubles, the audio (mix_block) running between frames as on
 * the device. Renders every screen to PPM for review (DIR/page-*.ppm, live-*.ppm, layer-*.ppm) and
 * drives the panel:
 *   taps    a layer button tapped opens its pages; held + a key / knob it does not
 *   FX      held + a white key: punch-in; knobs: filter, dust, duck
 *   SEQ     held: the steps on the white keys (drums: the sound played last), OCT: pages, a step key
 *           held + KNOB 2 / 3: level / ratchet
 *   EDIT    held + a key: erase; OCT- / OCT+: undo / redo; KNOB 1 shift, 2 length x2
 *   ARP     held + a key: a roll; KNOB 1 the rate
 *   SCL     held + a key: the key of the song
 *   GLO     held + keys: mute, solo, tap tempo; knobs: levels
 *   REC     press: arm / record at once; held: the clear ring, to the end: cleared (undo brings it back)
 *   SAVE    tapped: the song page; held: the SONG layer (sections A..D: play / store, SONG REC)
 *   DRUMS   the grid: sound / step / hit / level knobs, GRID <-> KIT
 * then 20000 frames of random use: every draw stays on the screen. */
#define FELUCCA_ARRANGER 1
#define main hostsim_main
#include "hostsim.c"
#undef main
#include <assert.h>
static uint16_t screen[240*240];
static void lcd_sync(void) {}
static void lcd_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint16_t *p)
{ uint32_t i,j; assert(x+w<=240 && y+h<=240); for(j=0;j<h;j++) for(i=0;i<w;i++) screen[(y+j)*240+x+i]=p[j*w+i]; }
#include "../firmware/src/gfx.c"
static void lcd_fill(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint16_t c)
{ uint32_t i,j; assert(x+w<=240&&y+h<=240); for(j=0;j<h;j++)for(i=0;i<w;i++)screen[(y+j)*240+x+i]=swap16(c); }
static int32_t encs[7];
static uint32_t fm1_ticks(void) { return fm1_ms * 1000u * 24u; }
#define FM1_TICKS_PER_US 24u
static int32_t fm1_enc_take(uint32_t e) { int32_t s = encs[e]; encs[e] = 0; return s; }
static uint8_t fm1_led[16], fm1_led_dim[16];
#define FM1_NCOL 16u
static const int8_t FM1_KEYMAP[5][16];
static void fm1_led_key(uint32_t id, int on) { (void)id; (void)on; }
static uint32_t edges_btn, notes_seen;
static uint32_t fm1_input_edges(int x) { uint32_t e = edges_btn; (void)x; edges_btn = 0; return e; }
static uint32_t fm1_input_note_edges(void) { uint32_t e = fm1_in.notes & ~notes_seen; notes_seen = fm1_in.notes; return e; }
static void fm1_wdt_feed(void) {}
static int32_t fm1_adc_read(int c) { (void)c; return -1; }
static struct { uint32_t magic, stage, page, home, ui_frames; } felucca_dbg;
#define FELUCCA_ICONS 0
#define SCOPE_N 512u
static int16_t scope_buf[SCOPE_N];
static uint32_t scope_w;
#include "../firmware/src/panel.c"
#include "../firmware/src/ui.c"
static uint32_t saves, loads;
static int project_used(uint32_t i) { return i < 2; }
static void project_save(uint32_t i) { (void)i; saves++; ui_message("SAVED"); }
static void project_load(uint32_t i) { (void)i; loads++; }
static void arrangement_save(void) {}
static uint32_t arrangement_ready(void) { return 3; }
static void arrangement_apply(uint32_t s) { (void)s; }
static void song_backup(void) {}
static void song_restore(void) {}
static uint32_t sec_stores, sec_loads;
static void section_store(uint32_t s) { sec_stores++; live_sec = (int8_t)s; }
static void section_load(uint32_t s) { sec_loads++; live_sec = (int8_t)s; }
#include "../firmware/src/upreset.c"
static void settings_save(void) {}
#include "../firmware/src/ui_song.c"
#include "../firmware/src/ui_studio.c"
#include "../firmware/src/icons.c"
#include "../firmware/src/ui_draw.c"
#include "../firmware/src/ui_layers.c"
#include "../firmware/src/ui_menu.c"
#include "../firmware/src/ui_input.c"
#include "../firmware/src/splash.c"

int main(void) {
 host_tracks_init();panel=PANEL_DEFAULT;layers_init();settings.palette=4;palette_set(4);
 track_t *t=&trk[0];song.sel=0;t->eng_req=0;apply_preset_to(t,0);
 t->p[P_E2]=77;t->p[P_LEVEL]=97;
 assert(up_store(0,"CUSTOM")==3);assert(up_bind(0,0,1)==3);
 t->p[P_LEVEL]=83;t->p[P_PAN]=9;t->step[0].note[0]=67;
 apply_preset_to(t,1);assert(t->p[P_E2]==77&&t->p[P_LEVEL]==83&&t->p[P_PAN]==9&&t->step[0].note[0]==67&&t->user==1);
 assert(up_bind(0,NENGINES,0)==1);
 assert(up_store(1,"SECOND")==3);assert(up_bind(1,0,1)==1);
 t->p[P_E2]=68;assert(up_store(0,"REVISED")==3);assert(up_rec(0)->target_engine==0&&up_rec(0)->target_preset==1);
 apply_preset_to(&trk[1],1); /* another part, original engine defaults */
 trk[1].eng_req=0;apply_preset_to(&trk[1],1);assert(trk[1].p[P_E2]==68);
 assert(up_bind(0,127,127)==3);apply_preset_to(t,1);assert(t->user==0);
 ui.home=1;ui.force=1;ui_draw();
 static uint16_t before[240*240];memcpy(before,screen,sizeof screen);
 t->eng_req=11;apply_preset_to(t,0);t->p[P_E3]=88;t->p[P_E6]=36;
 assert(up_store(2,"DX EDIT")==3);assert(up_rec(2)->xpatch[112]==88&&up_rec(2)->xpatch[117]==36);
 t->p[P_E3]=0;t->p[P_E6]=0;assert(up_load(2)==0);assert(t->p[P_E3]==88&&t->p[P_E6]==36);
 for(unsigned i=0;i<SCOPE_N;i++)scope_buf[i]=(i%64<32?1:-1)*12000;
 ui.home=1;ui.force=1;ui_draw();
 unsigned changed=0;for(unsigned i=0;i<240*240;i++)if(screen[i]!=before[i])changed++;
 assert(changed>240); /* real scope curve, not only its horizontal baseline */
 FILE *f=fopen("build/host/scope-fixed.ppm","wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned i=0;i<240*240;i++){uint16_t c=swap16(screen[i]);uint8_t rgb[3]={(c>>11)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};fwrite(rgb,1,3,f);}fclose(f);
 puts("PASS: factory binding, duplicate rejection, rewrite preservation, unbind, all tracks, scope drawing");
 return 0;
}
