/* SPDX-License-Identifier: GPL-3.0-only */
#define main hostsim_main
#include "hostsim.c"
#undef main
#include <assert.h>
int main(void)
{
    unsigned p, j, b, maxvoices = 0, peak = 0;
    host_tracks_init();
    host_preset(&trk[0], NENGINES - 2u, 0);
    host_preset(&trk[1], NENGINES - 1u, 2);
    host_preset(&trk[2], NENGINES - 2u, 2);
    for (p = 0; p < NPART; ++p) trk[p].p[P_VOICE] = V_POLY;
    for (b = 0; b < 3u * FS / CTL; ++b) {
        int32_t out[2 * CTL];
        if (b % 31u == 0)
            for (p = 0; p < NPART; ++p)
                trk_note_on(&trk[p], 40 + (b / 31u * 7u + p * 4u) % 44u, 100);
        mix_block(out, CTL);
        unsigned busy = busy_now();
        assert(busy <= NVOICE);
        if (busy > maxvoices) maxvoices = busy;
        for (p = 0; p < NPART; ++p) {
            unsigned held = 0;
            for (j = 0; j < NVOICE; ++j) held += trk[p].v[j].active && trk[p].v[j].stage != 4u;
            assert(held <= 4);
        }
        for (j = 0; j < 2u * CTL; ++j) {
            unsigned a = (unsigned)abs(out[j]);
            assert(a < 30000);
            if (a > peak) peak = a;
        }
    }
    for (p = 0; p < NPART; ++p)
        for (j = 0; j < 128; ++j) trk_note_off(&trk[p], j);
    for (b = 0; b < 8u * FS / CTL; ++b) {
        int32_t out[2 * CTL];
        mix_block(out, CTL);
    }
    assert(busy_now() == 0);
    printf("PASS: PLUCK/ADDIT/PLUCK mixed stress, shared max=%u, each part <=4, peak=%u, release frees every voice\n", maxvoices, peak);
    return 0;
}
