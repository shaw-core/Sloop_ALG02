/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the user preset record (firmware/src/upreset.c, -DUP_HOST part):
 * UP_PUT parsing, a bank round trip through storage.c on a simulated NOR,
 * bank / record version checks, map-by-count, pattern <-> steps. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define __attribute__(x)
#define UP_HOST 1
#include "../firmware/src/core.h"

static uint8_t nor[0x100000];
static int st_read(uint32_t off, void *dst, uint32_t n) { memcpy(dst, nor + off, n); return 0; }
static int st_erase(uint32_t off) { memset(nor + off, 0xFF, 4096); return 0; }
static int st_prog(uint32_t off, const void *src, uint32_t n)
{
    const uint8_t *s = src;
    uint32_t i;
    for (i = 0; i < n; i++)
        nor[off + i] &= s[i];
    return 0;
}
#include "../firmware/src/storage.c"
#include "../firmware/src/upreset.c"

static int check(const char *what, int ok)
{
    printf("%-46s %s\n", what, ok ? "ok" : "FAIL");
    return ok ? 0 : 1;
}

static uint32_t put_frame(uint8_t *a, uint32_t slot, uint32_t eng, const char *name, int32_t base)
{
    uint32_t n = 0, i;
    a[n++] = (uint8_t)slot;
    a[n++] = (uint8_t)eng;
    for (i = 0; name[i]; i++)
        a[n++] = (uint8_t)name[i];
    a[n++] = 0;
    for (i = 0; i < P_COUNT; i++) {
        uint32_t u = (uint32_t)(base + (int32_t)i + 8192);
        a[n++] = u & 127u;
        a[n++] = (u >> 7) & 127u;
    }
    for (i = 0; i < 16u; i++) {
        a[n++] = (uint8_t)(i % 3u ? 40u + i : 0u);  /* rests on 0, 3, 6 .. */
        a[n++] = (uint8_t)(i == 3u ? 4u : i % 3u ? 1u : 2u);   /* step 3: tie; slide on a rest drops */
    }
    return n;
}

int main(void)
{
    uint8_t a[640];
    up_rec_t r, got;
    uint32_t n, slot = 99, i;
    int bad = 0, len, ok;
    int16_t v[P_COUNT], def[P_COUNT];
    memset(nor, 0xFF, sizeof nor);

    n = put_frame(a, 5, 2, "Bass One", -40);
    bad += check("UP_PUT frame < 640 bytes", 5u + n + 1u < 640u);
    bad += check("UP_PUT parses", up_parse(a, n, &r, &slot) == 0 && slot == 5u && r.engine == 2u &&
                                      up_valid(&r) && !memcmp(r.name, "Bass One", 8) && !r.name[8]);
    ok = 1;
    for (i = 0; i < P_COUNT; i++)
        ok &= r.p[i] == (int16_t)(-40 + (int32_t)i);
    bad += check("UP_PUT values (negative v14 too)", ok);
    bad += check("pattern: rest drops flags, tie has no note",
                 r.note[0] == 0 && r.flags[0] == 0 && r.note[1] == 41 && r.flags[1] == 1 && r.note[3] == 0 &&
                     r.flags[3] == 4);
    bad += check("UP_PUT short frame -> args", up_parse(a, n - 1u, &r, &slot) == 1);
    n = put_frame(a, 32, 0, "X", 0);
    bad += check("UP_PUT slot 32 -> args", up_parse(a, n, &r, &slot) == 1);
    n = put_frame(a, 0, NENGINES, "X", 0);
    bad += check("UP_PUT bad engine -> args", up_parse(a, n, &r, &slot) == 1);
    n = put_frame(a, 0, 0, "", 0);
    bad += check("UP_PUT empty name -> args", up_parse(a, n, &r, &slot) == 1);
    n = put_frame(a, 0, 0, "THIRTEEN CHRS", 0);
    bad += check("UP_PUT 13-char name -> args", up_parse(a, n, &r, &slot) == 1);
    n = put_frame(a, 0, 0, "TWELVE CHARS", 0);
    bad += check("UP_PUT 12-char name ok", up_parse(a, n, &r, &slot) == 0 && !memcmp(r.name, "TWELVE CHARS", 12));
    {
        char nm[13];
        *up_rec(31) = r;
        memcpy(up_rec(31)->name, "Low case", 9);
        up_name(31, nm);
        bad += check("name shown upper case", !strcmp(nm, "LOW CASE"));
    }

    /* bank round trip through storage.c */
    n = put_frame(a, 17, 3, "Keys", 7);
    up_parse(a, n, &r, &slot);
    up_bank[1].magic = UP_BANK_MAGIC;
    up_bank[1].rsize = sizeof(up_rec_t);
    up_bank[1].nslot = UP_PER_BANK;
    *up_rec(17) = r;
    bad += check("bank fits one object", sizeof(up_bank_t) <= ST_PAYLOAD_MAX);
    bad += check("bank save", st_save(OBJ_UPRESET0 + 1, &up_bank[1], sizeof up_bank[1]) == 0);
    memset(up_bank, 0, sizeof up_bank);
    len = st_load(OBJ_UPRESET0 + 1, &up_bank[1], sizeof up_bank[1]);
    up_bank_check(1, len);
    got = *up_rec(17);
    bad += check("bank load: the record is back", up_used(17) && !memcmp(&got, &r, sizeof r));
    bad += check("other slots empty", !up_used(16) && !up_used(18) && !up_used(0));
    len = st_load(OBJ_UPRESET0, &up_bank[0], sizeof up_bank[0]);
    up_bank_check(0, len);
    bad += check("bank 0 never written -> empty", len < 0 && !up_used(0) && up_bank[0].magic == 0);
    bad += check("banks in 0xDC000..0xDFFFF", st_sector(OBJ_UPRESET0, 0) == 0xDC000u &&
                                                   st_sector(OBJ_UPRESET0 + 1, 1) == 0xDF000u &&
                                                   st_sector(OBJ_PROJECT0 + 3, 1) + 4096u <= 0xA0000u);
    up_bank[1].rsize = 190;                                 /* another record layout */
    up_bank_check(1, (int)sizeof up_bank[1]);
    bad += check("bank with another record size -> empty", !up_used(17));
    up_bank[1].magic = UP_BANK_MAGIC;
    up_bank[1].rsize = sizeof(up_rec_t);
    up_bank[1].nslot = UP_PER_BANK;
    *up_rec(17) = r;
    up_rec(17)->ver = UP_VER + 1u;
    bad += check("record with another version -> empty", !up_used(17));

    /* map by count: a record from a build with 2 parameters fewer */
    for (i = 0; i < P_COUNT; i++)
        def[i] = (int16_t)(1000 + i);
    r.np = P_COUNT - 2u;
    for (i = 0; i < P_COUNT; i++)
        r.p[i] = (int16_t)i;
    up_params(&r, v, def);
    ok = 1;
    for (i = 0; i < P_E0; i++)
        ok &= v[i] == (i < P_E0 - 2u ? (int16_t)i : def[i]);
    for (i = 0; i < 8u; i++)
        ok &= v[P_E0 + i] == (int16_t)(P_E0 - 2u + i);
    bad += check("np < P_COUNT: mapped by count", ok);
    /* a record saved before the SLICER (P_COUNT 53, P_E0 45): the four SLICER parameters (just
     * before P_E0) take their defaults, everything else keeps its id */
    r.np = 53;
    for (i = 0; i < 53u; i++)
        r.p[i] = (int16_t)(-100 + i);
    up_params(&r, v, def);
    ok = P_SLCR == 45 && P_SLDEPTH + 1 == P_CHORD && P_CHORD == 49 && P_E0 == 50;
    for (i = 0; i < 45u; i++)
        ok &= v[i] == (int16_t)(-100 + i);
    for (i = P_SLCR; i <= P_CHORD; i++)
        ok &= v[i] == def[i];
    for (i = 0; i < 8u; i++)
        ok &= v[P_E0 + i] == (int16_t)(-100 + 45 + i);
    bad += check("old record (np 53): SLICER and CHORD defaults, E0..E7 kept", ok);
    /* a record of SLOOP 1.0 (P_COUNT 57, P_E0 49): CHORD (SLOOP 2.0) takes its default */
    r.np = 57;
    for (i = 0; i < 57u; i++)
        r.p[i] = (int16_t)(60 + i);
    up_params(&r, v, def);
    ok = 1;
    for (i = 0; i < P_CHORD; i++)
        ok &= v[i] == (int16_t)(60 + i);
    ok &= v[P_CHORD] == def[P_CHORD];
    for (i = 0; i < 8u; i++)
        ok &= v[P_E0 + i] == (int16_t)(60 + 49 + i);
    bad += check("SLOOP 1.0 record (np 57): CHORD default, the rest kept", ok);
    r.np = P_COUNT;
    for (i = 0; i < P_COUNT; i++)
        r.p[i] = (int16_t)i;
    up_params(&r, v, def);
    ok = 1;
    for (i = 0; i < P_COUNT; i++)
        ok &= v[i] == (int16_t)i;
    bad += check("np == P_COUNT: as stored", ok);

    {   /* steps -> pattern (UP_STORE) */
        step_t st[NSTEP];
        memset(st, 0, sizeof st);
        for (i = 0; i < 16u; i++)
            st[i].time = ST_REST;
        st[0] = (step_t){{60, 64, 67, 0}, 3, ST_NOTE, SF_ACCENT | SF_SLIDE, 100};
        st[1] = (step_t){{0}, 0, ST_TIE, 0, 0};
        st[2] = (step_t){{50}, 0, ST_NOTE, SF_ACCENT, 0};   /* n = 0: empty */
        st[20] = (step_t){{70}, 1, ST_NOTE, 0, 90};         /* beyond 16: not stored */
        up_pat_from(&r, st);
        bad += check("steps -> pattern", r.note[0] == 60 && r.flags[0] == 3 && r.note[1] == 0 && r.flags[1] == 4 &&
                                             r.note[2] == 0 && r.flags[2] == 0 && !up_pat_empty(&r));
        memset(st, 0, sizeof st);
        up_pat_from(&r, st);
        bad += check("empty sequencer -> empty pattern", up_pat_empty(&r));
    }
    for (i = NENGINES - 2u; i < NENGINES; i++) {
        uint32_t j;
        n = put_frame(a, 17, i, "Algorithm", 0);
        ok = up_parse(a, n, &r, &slot) == 0 && r.engine == i;
        up_bank[1].magic = UP_BANK_MAGIC;
        up_bank[1].rsize = sizeof(up_rec_t);
        up_bank[1].nslot = UP_PER_BANK;
        *up_rec(17) = r;
        ok &= st_save(OBJ_UPRESET0 + 1, &up_bank[1], sizeof up_bank[1]) == 0;
        memset(up_bank, 0, sizeof up_bank);
        len = st_load(OBJ_UPRESET0 + 1, &up_bank[1], sizeof up_bank[1]);
        up_bank_check(1, len);
        got = *up_rec(17);
        ok &= up_used(17) && got.engine == i && !memcmp(&got, &r, sizeof r);
        up_params(&got, v, def);
        for (j = 0; j < 8u; j++) ok &= v[P_E0 + j] == r.p[P_E0 + j];
        bad += check(i == NENGINES - 2u ? "PLUCK: parse/save/load parameters" : "ADDIT: parse/save/load parameters", ok);
    }

    { /* Exact ALG02 record layout, all 16 slots: expansion must not overwrite unread source records. */
        typedef struct { uint8_t used,ver,engine,np;char name[12];int16_t p[72];uint8_t note[16],flags[16]; } old_rec;
        static struct { uint32_t magic;uint16_t rsize,nslot;old_rec r[16]; } old;
        uint32_t j,k;
        memset(&old,0,sizeof old);old.magic=UP_BANK_MAGIC;old.rsize=192;old.nslot=16;
        for(j=0;j<16;j++) {
            old.r[j].used=UP_USED;old.r[j].ver=1;old.r[j].engine=j%11;old.r[j].np=P_COUNT;
            snprintf(old.r[j].name,12,"SLOT%02u",j);
            for(k=0;k<P_COUNT;k++)old.r[j].p[k]=(int16_t)(k+(j%8));
            old.r[j].note[0]=60+j;old.r[j].flags[0]=1;
        }
        bad+=check("legacy ALG02 bank layout is 3080 bytes",sizeof old==3080);
        memcpy(&up_bank[0],&old,sizeof old);up_bank_check(0,sizeof old);ok=1;
        for(j=0;j<16;j++) {
            const up_rec_t *r0=up_rec(j);
            ok &= up_used(j)&&r0->ver==UP_VER&&r0->engine==j%11&&!memcmp(r0->name,old.r[j].name,12);
            for(k=0;k<P_COUNT;k++)ok &= r0->p[k]==old.r[j].p[k];
            for(k=0;k<128;k++)ok &= r0->xpatch[k]==0;
            ok &= r0->note[0]==60+j&&r0->flags[0]==1;
        }
        bad+=check("ALG02 -> ALG03: all 16 names, engines, parameters and patterns retained",ok);
        n=put_frame(a,3,11,"DX7 TEST",0);
        for(j=0;j<128;j++)a[n+j]=(uint8_t)j;
        bad+=check("extended patch UP_PUT parses",up_parse(a,n+128,&r,&slot)==0&&slot==3);
        ok=1;for(j=0;j<128;j++)ok &= r.xpatch[j]==j;
        *up_rec(3)=r;up_bank_check(0,sizeof up_bank[0]);
        ok &= st_save(OBJ_UPRESET0,&up_bank[0],sizeof up_bank[0])==0;
        memset(up_bank,0,sizeof up_bank);len=st_load(OBJ_UPRESET0,&up_bank[0],sizeof up_bank[0]);up_bank_check(0,len);
        ok &= up_used(3)&&!memcmp(up_rec(3)->xpatch,r.xpatch,128);
        bad+=check("128-byte voice survives flash bank save / reboot load",ok);
        bad+=check("truncated extended voice rejected",up_parse(a,n+127,&r,&slot)!=0);
        a[n+10]=128;bad+=check("non-7-bit extended voice rejected",up_parse(a,n+128,&r,&slot)!=0);
    }
    { /* Exact ALG03 record, all 16 voices and patterns, expanded backwards. */
        typedef struct {uint8_t used,ver,engine,np;char name[12];int8_t p[P_COUNT];uint8_t xp[128],note[16],flags[16];} old_rec;
        static struct {uint32_t magic;uint16_t rsize,nslot;old_rec r[16];} old;
        memset(&old,0,sizeof old);old.magic=UP_BANK_MAGIC;old.rsize=234;old.nslot=16;
        for(i=0;i<16;i++){old.r[i].used=UP_USED;old.r[i].ver=2;old.r[i].engine=11;old.r[i].np=P_COUNT;snprintf(old.r[i].name,12,"DX%u",i);memset(old.r[i].xp,i+1,128);old.r[i].p[4]=i;old.r[i].note[0]=60+i;}
        memcpy(&up_bank[0],&old,sizeof old);up_bank_check(0,sizeof old);ok=sizeof old==3752;
        for(i=0;i<16;i++)ok &= up_used(i)&&up_rec(i)->xpatch[127]==i+1&&up_rec(i)->p[4]==i&&up_rec(i)->note[0]==60+i&&up_rec(i)->target_engine==255;
        bad+=check("ALG03 -> ALG04 all 16 voices/patterns, no bindings",ok);
    }
    printf("%s\n", bad ? "USER PRESET TEST FAILED" : "user preset test passed");
    return bad != 0;
}
