/* SPDX-License-Identifier: GPL-3.0-only */
#define main hostsim_main
#include "hostsim.c"
#undef main
#include <assert.h>
int main(void) {
 uint32_t note,alg,block,i,j,mode,wave;uint32_t cases=0;
 for(note=0;note<128;note++)for(alg=0;alg<32;alg++) {
  track_t *t=&trk[0];voice_t *v=&t->v[0];vmod_t m={0};
  host_tracks_init();host_preset(t,11,0);t->p[P_E0]=alg+1;t->p[P_E1]=alg%8;
  dx7_factory(t,1);t->p[P_E0]=alg+1;t->p[P_E1]=alg%8;
  for(j=0;j<6;j++) {uint8_t *o=t->xpatch+j*17;o[15]=(uint8_t)((j*5)<<1)|(alg&1);o[16]=99;o[3]=99;}
  t->xpatch[114]=99;t->xpatch[115]=99;t->xpatch[116]=(uint8_t)((alg%6)<<1)|113;
  v->note=note;v->vel=127;v->active=v->gate=1;ENG_DX7.note_on(t,v);
  m.inc=PITCH_INC[note*16];m.pitch16=note*16;m.shape=16384;
  for(block=0;block<192;block++) {
   int32_t out[CTL]={0};if(block==96)v->gate=0;
   m.amp0=m.amp1=dx7_amp(t,v);ENG_DX7.render(t,v,out,CTL,&m);
   for(i=0;i<CTL;i++)assert(out[i]>-40000&&out[i]<40000);
  }
  assert(!v->active);cases++;
 }
 for(note=0;note<128;note++)for(mode=0;mode<4;mode++)for(wave=0;wave<5;wave++) {
  track_t *t=&trk[1];voice_t *v=&t->v[0];vmod_t m={0};
  host_tracks_init();host_preset(t,12,0);t->p[P_E0]=wave;t->p[P_E4]=mode;
  t->p[P_E2]=t->p[P_E3]=t->p[P_E6]=127;v->note=note;v->gate=v->active=1;ENG_VA.note_on(t,v);
  m.inc=PITCH_INC[note*16];m.pitch16=note*16;m.shape=16384;m.amp0=m.amp1=24000;
  for(block=0;block<96;block++) {
   int32_t out[CTL]={0};t->p[P_E1]=t->p[P_E5]=block&127;ENG_VA.render(t,v,out,CTL,&m);
   for(i=0;i<CTL;i++)assert(out[i]>-40000&&out[i]<40000);
  }
  cases++;
 }
 printf("PASS: %u DX7/VA cases, all MIDI notes, 32 FM routings, 6 LFO waves, 5 VA waves / 4 filters, release and bounds\n",cases);
 return 0;
}
