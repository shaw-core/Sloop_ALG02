#!/usr/bin/env python3
"""Export actual firmware preset loading to portable web-library JSON (no MIDI/flash writes)."""
import json, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
body=(root/'tests/ui_pages_test.c').read_text().split('int main(int argc, char **argv)')[0]
body+=r'''
int main(void) {
 uint32_t e,k,i; host_tracks_init();
 printf("{\"format\":\"felucca-library\",\"version\":1,\"kind\":\"library\",\"pE0\":%u,\"engines\":[",P_E0);
 for(e=0;e<NENGINES;e++) printf("%s\"%s\"",e?",":"",ENGINES[e]->name);
 printf("],\"patches\":[");
 for(e=0;e<NENGINES;e++) for(k=0;k<ENGINES[e]->npresets;k++) {
  host_tracks_init(); set_engine_of(&trk[0],e); apply_preset_to(&trk[0],k);
  printf("%s{\"name\":\"%s\",\"engine\":%u,\"engineName\":\"%s\",\"params\":[",e||k?",":"",ENGINES[e]->presets[k].name,e,ENGINES[e]->name);
  for(i=0;i<P_COUNT;i++) printf("%s%d",i?",":"",trk[0].p[i]);
  printf("],\"tags\":[\"factory\",\"%s\"]",ENGINES[e]->name);
  if(ENGINES[e]==&ENG_DX7) {
   printf(",\"xpatch\":[");for(i=0;i<128;i++)printf("%s%u",i?",":"",trk[0].xpatch[i]);printf("]");
  }
  printf("}");
 }
 printf("]}\n"); return 0;
}
'''
with tempfile.TemporaryDirectory() as temp:
    # Relative includes in the test harness resolve against tests/.
    src=root/'tests/.factory_export_tmp.c'
    try:
        src.write_text(body)
        exe=Path(temp)/'export'
        subprocess.run(['cc','-O2','-w','-I'+str(root/'build/gen'),'-I'+str(root/'firmware/src'),str(src),'-lm','-o',str(exe)],check=True)
        data=json.loads(subprocess.check_output([str(exe)]))
    finally: src.unlink(missing_ok=True)
base=root/'web/presets';base.mkdir(exist_ok=True)
for engine in data['engines']:
    patches=[dict(p,source='SLOOP / Felucca / Sloop_ALG02 firmware preset definitions') for p in data['patches'] if p['engineName']==engine]
    obj=dict(data,patches=patches)
    (base/(engine.lower()+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
(base/'all-engines.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Exported',len(data['patches']),'factory sounds for',len(data['engines']),'engines')
