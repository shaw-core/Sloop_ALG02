#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Render the twelve new factory sounds with the exact host DSP code."""
import os
from pathlib import Path
import subprocess
import sys
import wave

root = Path(__file__).resolve().parents[1]
dest = Path(sys.argv[1] if len(sys.argv) > 1 else root / "build/demos").resolve()
dest.mkdir(parents=True, exist_ok=True)
groups = [(9, "PLUCK", ["NYLON", "STEEL", "HARP", "MUTED", "WIRE", "BASS"]),
          (10, "ADDIT", ["PURE", "HOLLOW", "PRISM", "GLASS", "ORBIT", "METAL"])]
chunks, index = [], []
for engine, label, names in groups:
    for preset, name in enumerate(names):
        path = dest / f"{engine:02d}_{preset:02d}_{label}_{name}.wav"
        env = dict(os.environ, SECS="4", PRESET="1")
        subprocess.run([str(root / "build/host/hostsim"), str(engine), str(preset), "0", str(path)],
                       cwd=root, env=env, check=True)
        with wave.open(str(path)) as f:
            assert f.getnchannels() == 2 and f.getsampwidth() == 2 and f.getframerate() == 44100
            frames = f.readframes(f.getnframes())
        # A 20 ms end fade is only for joining the preview clips; individual files are untouched.
        import array
        data = array.array("h", frames)
        if sys.byteorder != "little": data.byteswap()
        fade = min(882, len(data) // 2)
        for i in range(fade):
            for c in range(2):
                at = len(data) - 2 * fade + 2 * i + c
                data[at] = int(data[at] * (fade - i - 1) / fade)
        if sys.byteorder != "little": data.byteswap()
        index.append(f"{len(chunks) * 4.5:05.1f}s  {label} / {name}")
        chunks.append(data.tobytes() + bytes(22050 * 4))
with wave.open(str(dest / "ALG01_all_presets.wav"), "wb") as out:
    out.setparams((2, 2, 44100, 0, "NONE", "not compressed"))
    out.writeframes(b"".join(chunks))
(dest / "LISTEN.txt").write_text("Desktop renders, not recordings from FM-1 hardware.\n44.1 kHz stereo PCM.\n\n" + "\n".join(index) + "\n")
print(f"Rendered {len(chunks)} presets and 54-second preview into {dest}")
