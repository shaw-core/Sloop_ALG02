import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html = readFileSync(new URL('./editor.html', import.meta.url), 'utf8');
const proto = html.slice(html.indexOf('/*PROTO-BEGIN*/'), html.indexOf('/*PROTO-END*/'));
const e = vm.runInNewContext(proto + '\n;({readDX7Sysex, readExternalPresets, cleanPatch, libraryFile, readLibraryFile, parse, req, CMD})',
 {setTimeout, clearTimeout, setInterval, clearInterval, console, TextEncoder, TextDecoder, Uint8Array});
const ctx={engines:['ANALOG','FM','PHASE','CHIP','SAMPLE','VOICE','TRIO','WHEEL','GRAIN','PLUCK','ADDIT','DX7','VA'],pe0:50};
function frame(data,type) {return Uint8Array.from([240,67,0,type,data.length>>7,data.length&127,...data,(-data.reduce((a,b)=>a+b,0))&127,247]);}
const raw=Array(4096).fill(0);raw[110]=4;raw[111]=11;raw[117]=24;
for(let i=0;i<10;i++)raw[118+i]='EP TEST   '.charCodeAt(i);
const syx=frame(raw,9), lib=e.readDX7Sysex(syx,ctx,'test-source');
assert.equal(lib.patches.length,32);assert.equal(lib.patches[0].name,'EP TEST');assert.equal(lib.patches[0].params[50],5);
assert.equal(lib.patches[0].xpatch[111],11);
const double=new Uint8Array(syx.length*2);double.set(syx);double.set(syx,syx.length);
assert.equal(e.readDX7Sysex(double,ctx).patches.length,64);
const single=Array(155).fill(0);single[134]=31;single[135]=7;single[136]=1;single[144]=24;
assert.equal(e.readDX7Sysex(frame(single,0),ctx).patches[0].xpatch[110],31);
const bad=syx.slice();bad[10]^=1;assert.throws(()=>e.readDX7Sysex(bad,ctx),/checksum/);
assert.throws(()=>e.readDX7Sysex(syx.slice(0,-1),ctx),/Truncated/);
assert.throws(()=>e.readDX7Sysex(frame(Array(200).fill(0),9),ctx),/Expected/);
assert.throws(()=>e.readDX7Sysex(syx,{engines:['ANALOG']}),/ALG03/);
assert.throws(()=>e.readExternalPresets(new TextEncoder().encode('not a preset'),ctx),/Unsupported/);
assert.throws(()=>e.cleanPatch({xpatch:[1,2]}),/Invalid DX7/);
const pt=e.cleanPatch(lib.patches[0]);
// Import schema conversion supplies p; verify xpatch + provenance survive both directions.
const imported=e.readLibraryFile(lib,ctx).patches[0];
const back=e.readLibraryFile(e.libraryFile('library',[imported],ctx),ctx).patches[0];
assert.deepEqual(Array.from(back.xpatch),Array.from(imported.xpatch));assert.equal(back.source,'test-source');
const wire=e.req.upPut(3,imported)[1];assert.deepEqual(Array.from(wire.slice(-128)),Array.from(imported.xpatch));
assert.deepEqual(Array.from(e.parse[e.CMD.XPATCH]([0,0,...imported.xpatch]).xpatch),Array.from(imported.xpatch));
if(process.argv[2]) {
 const real=e.readDX7Sysex(new Uint8Array(readFileSync(process.argv[2])),ctx,'ROM1A test fixture');
 assert.equal(real.patches.length,32);assert.equal(real.patches[0].name,'BRASS   1');
 console.log('PASS: real ROM1A bank: 32 voices, BRASS 1, checksum valid.');
}
const record=Array(59).fill(0);record[18]=3;
function fm1Frame(marker,slot=0) {
 const rec=record.slice();rec[18]=marker;const packed=[];
 for(let i=0;i<59;i+=7) {const group=rec.slice(i,i+7);packed.push(group.reduce((n,b,k)=>n|((b>>7)<<k),0),...group.map(b=>b&127));}
 const payload=[...single,...packed];return Uint8Array.from([240,67,0,125,4,slot,...payload,payload.reduce((n,b)=>n+(~b&127),0)&127,247]);
}
const mixed=new Uint8Array(462);mixed.set(fm1Frame(3,0));mixed.set(fm1Frame(90,1),231);
const fm1=e.readExternalPresets(mixed,ctx,'Baud Girl backup');assert.equal(fm1.patches.length,1);assert.equal(fm1.sourceSkipped,1);
assert.throws(()=>e.readExternalPresets(fm1Frame(90),ctx),/VA conversion unavailable/);
const badfm=fm1Frame(3);badfm[12]^=1;assert.throws(()=>e.readExternalPresets(badfm,ctx),/checksum/);
console.log('PASS: FM-1+VA backup FM extraction, VA exclusion, checksums and skipped counts.');
console.log('PASS: bank/single/multiple frames; checksum, truncation, unsupported format/device; JSON and slot payload preserve extended voice.');

assert.equal(e.cleanPatch({engineName:'ANALOG',xpatch:Array(128).fill(0),p:[1]}).xpatch,undefined);
console.log('PASS: non-DX7 bank voices never acquire a DX7 payload');
