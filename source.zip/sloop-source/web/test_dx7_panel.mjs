import {readFileSync} from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const html=readFileSync(new URL('./editor.html',import.meta.url),'utf8');
const source=html.slice(html.indexOf('let dxDetail = null;'),html.indexOf('$("dxread").addEventListener'));
function node(tag) {return {tag,children:[],style:{},events:{},append(x){this.children.push(x);},replaceChildren(){this.children=[];},addEventListener(e,f){this.events[e]=f;}};}
const root=node('root');const ctx=vm.runInNewContext(source+'\n;({draw:x=>{dxDetail=x;renderDXDetail();}})',{$:()=>root,document:{createElement:node}});
const voice=Array(128).fill(0);voice[100]=3;voice[97]=56;ctx.draw(voice);
function descendants(n) {return n.children.flatMap(c=>[c,...descendants(c)]);}
const all=descendants(root), labels=all.filter(n=>n.tag==='label');assert.equal(labels.length,145);
const coarse=labels.find(n=>n.textContent==='Coarse').children[0];coarse.value='12';coarse.events.change();
assert.equal(voice[100],25); // OP1: coarse in bits 1–5, fixed mode bit retained.
coarse.value='1000';coarse.events.change();assert.equal(voice[100],25);
const det=labels.find(n=>n.textContent==='Detune').children[0];det.value='10';det.events.change();assert.equal(voice[97],80);
const alg=labels.find(n=>n.textContent==='Algorithm').children[0];alg.value='32';alg.events.change();assert.equal(voice[110],31);
console.log('PASS: 6 operators + 19 globals, packed bit preservation, invalid edit rejection, algorithm 1-based display.');
