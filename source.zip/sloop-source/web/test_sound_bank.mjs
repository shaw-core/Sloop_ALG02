// Tests the actual Sound-page write handler with a simulated bank and controls.
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const html = readFileSync(new URL('./editor.html', import.meta.url), 'utf8');
const start = html.indexOf('$("quickreplace").addEventListener');
const end = html.indexOf('\nfunction renderBank()', start);
assert(start >= 0 && end > start);
const source = html.slice(start, end);
async function scenario({ used = false, name = '', accepted = true, drum = false, busy = false } = {}) {
  let handler, job;
  const writes = [], confirmations = [];
  const controls = { quickreplace: { addEventListener: (_, fn) => handler = fn },
    quickslot: { value: '7' }, quickname: { value: name } };
  const slots = Array.from({ length: 32 }, (_, slot) => ({ slot, used: false, name: '' }));
  slots[7] = { slot: 7, used, name: 'OLD SOUND' };
  vm.runInNewContext(source, {
    $: id => controls[id], dev: { bank: { slots } }, libBusy: busy, isDrum: () => drum,
    confirm: message => { confirmations.push(message); return accepted; },
    t: () => '{n} {name}', slotName: slot => `U${slot + 1}`,
    libOp: fn => { job = fn(); }, bank: { store: async (_, slot, storedName) => {
      writes.push({ slot, name: storedName }); return 0;
    } }, rqf: {}, checkRc: rc => assert.equal(rc, 0), refreshSlot: async () => {}, sayK: () => {}
  });
  handler(); if (job) await job;
  return { writes, confirmations };
}
let r = await scenario();
assert.equal(r.writes.length, 1); assert.equal(r.writes[0].slot, 7); assert.equal(r.writes[0].name, '');
r = await scenario({ used: true });
assert.equal(r.confirmations.length, 1); assert.equal(r.writes[0].name, 'OLD SOUND');
r = await scenario({ used: true, name: 'NEW SOUND' }); assert.equal(r.writes[0].name, 'NEW SOUND');
for (const options of [{ used: true, accepted: false }, { drum: true }, { busy: true }]) {
  r = await scenario(options); assert.equal(r.writes.length, 0);
}
assert.equal((html.match(/id="quickslot"/g) || []).length, 1);
assert.equal((html.match(/id="preseturlimport"/g) || []).length, 1);
console.log('PASS: empty slot, overwrite confirmation, preserve/rename, cancel, drum/busy guards; one selected slot only.');
const ustart = html.indexOf('$("preseturlimport").addEventListener');
const uend = html.indexOf('\n/* device bank */', ustart);
assert(ustart >= 0 && uend > ustart);
async function urlScenario({ url = 'https://example.test/patch.json', http = 200,
  text = '{"format":"felucca-patch","engine":0,"preset":0,"p":[]}', fail = false, oversized = false } = {}) {
  let handler, calls = 0, imports = 0, message;
  const button = { disabled: false, addEventListener: (_, fn) => handler = fn };
  const bytes = oversized ? new Uint8Array(4 * 1024 * 1024 + 1) : new TextEncoder().encode(text);
  vm.runInNewContext(html.slice(ustart, uend), {
    $: id => id === 'preseturlimport' ? button : { value: url }, URL, AbortController,
    setTimeout, clearTimeout, TextDecoder, Uint8Array, JSON, libCtx: () => ({}),
    readExternalPresets: bytes => JSON.parse(new TextDecoder().decode(bytes)),
    fetch: async (_, options) => {
      calls++; assert.equal(options.credentials, 'omit');
      if (fail) throw new Error('CORS');
      let sent = false;
      return { ok: http === 200, status: http, body: { getReader: () => ({
        read: async () => { if (sent) return { done: true }; sent = true; return { done: false, value: bytes }; },
        cancel: async () => {}
      }) } };
    }, importLibraryObject: async obj => { imports++; assert.equal(obj.engine, 0); return { imported: 1, skipped: 0 }; },
    t: () => ' patches', sayK: (_, m) => message = m
  });
  await handler(); assert.equal(button.disabled, false);
  return { calls, imports, message };
}
let u = await urlScenario(); assert.equal(u.imports, 1);
for (const options of [{ url: 'http://example.test/a.json' }, { url: 'https://user:password@example.test/a.json' }]) {
  u = await urlScenario(options); assert.equal(u.calls, 0); assert.equal(u.imports, 0);
}
for (const options of [{ http: 404 }, { text: '<html>not JSON</html>' }, { fail: true }, { oversized: true }]) {
  u = await urlScenario(options); assert.equal(u.imports, 0);
}
console.log('PASS: external JSON, HTTPS and credentials guards, HTTP/CORS/non-JSON/size errors; controls recover.');
