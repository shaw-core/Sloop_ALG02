/* SPDX-License-Identifier: GPL-3.0-only
 * VA: five band-limited oscillators, sync and four filter modes.
 * Independent implementation; does not embed Baud Girl's closed-source code.
 */
static const char *const VA_WAVE[]={"SAW","SQR","TRI","SIN","SYNC"};
static const char *const VA_FILT[]={"LP12","LP24","BP","HP"};
static uint32_t va_phase[NPART][4][5];
static void va_factory(track_t *t,uint32_t pi){(void)pi;memset(t->xpatch,0,128);}
static void va_note_on(track_t *t,voice_t *v){
 uint32_t j,part=(uint32_t)(t-trk)%NPART,vi=(uint32_t)(v-t->v)%4;
 for(j=0;j<5;j++)va_phase[part][vi][j]=j*0x33333333u;
 v->s[0]=v->s[1]=v->s[2]=v->s[3]=0;
}
static void va_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m){
 uint32_t *ph=va_phase[(uint32_t)(t-trk)%NPART][(uint32_t)(v-t->v)%4];
 uint32_t inc[5],i,j,mode=t->p[P_E4],wave=t->p[P_E0];
 int32_t super=t->p[P_E3]*258,cut=(t->p[P_E5]<<8)+m->cutoff;
 int32_t spread=t->p[P_E2],shape=t->p[P_E1];tsvf_t f;
 tsvf_coef(&f,cut,t->p[P_E6]);
 for(j=0;j<5;j++){
  int32_t cents=((int32_t)j-2)*spread/2;
  int64_t d=(int64_t)(m->inc>>8)*cents*151/1000;
  inc[j]=(uint32_t)clamp((int32_t)m->inc+(int32_t)d,1,0x70000000);
 }
 for(i=0;i<n;i++){
  int32_t sum=0,center=0,x,lp,hp,bp;uint32_t master=ph[2]+inc[2];
  for(j=0;j<5;j++){
   uint32_t step=inc[j],pw=0x10000000u+(uint32_t)shape*0x00D00000u;
   if(wave==4 && j!=2){step=(uint32_t)((uint64_t)step*(128+shape*4)/128);if(master<ph[2])ph[j]=0;}
   x=wave==1?osc_pulse(ph[j],step,pw):wave==2?osc_tri(ph[j]):wave==3?osc_sine(ph[j]):osc_saw(ph[j],step);
   if(j==2)center=x;sum+=x;ph[j]+=step;
  }
  x=mulq15(center,32767-super)+mulq15(sum/5,super);
  if(t->p[P_E7])x=softclip(x*(128+t->p[P_E7]*3)/128);
  { int32_t old=v->s[0],k=8192-t->p[P_E6]*7600/127;
    lp=tsvf_lp(&f,x>>1,&v->s[0],&v->s[1]);bp=(old+v->s[0])/2;
    hp=(x>>1)-(k*bp>>12)-lp; }
  if(mode==1)lp=tsvf_lp(&f,lp,&v->s[2],&v->s[3]);
  else if(mode==2)lp=bp;
  else if(mode==3)lp=hp;
  out[i]+=mulq15(mulq15(clamp(lp*2,-30000,30000),amp_at(m,i)),VOICE_FS);
 }
}
static const preset_t VA_PRESETS[]={
 {"SUPER SAW",{0,64,35,100,1,100,15,5},{10,90,100,70},0,0,FX(0,15,15,30)},
 {"SYNC LEAD",{4,70,5,40,0,110,25,20},{0,75,105,45},0,1,FX(0,0,15,25)},
 {"VA PAD",{0,64,20,95,1,65,10,0},{70,100,95,100},0,0,FX(0,35,20,60)}
};
static const engine_t ENG_VA={"VA",{"OSC","FLT"},{
 {"WAVE",F_ENUM,0,4,0,VA_WAVE,0},{"SHAPE",F_PCT,0,127,64,0,0},
 {"DETUNE",F_INT,0,127,20,0,"ct"},{"SUPER",F_PCT,0,127,80,0,0},
 {"FILTER",F_ENUM,0,3,1,VA_FILT,0},{"CUTOFF",F_CUTOFF,0,127,100,0,0},
 {"RES",F_PCT,0,127,20,0,0},{"DRIVE",F_PCT,0,127,0,0,0}},VA_PRESETS,3,1,
 va_note_on,va_render,0x87F0,{P_E5,P_E6,P_E1,P_E3},4};
