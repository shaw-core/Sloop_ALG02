/* SPDX-License-Identifier: GPL-3.0-only */
/* SLOOP boot splash: the logo (tools/gen_logo.py -> sloop_logo.h: 16 colours, RLE runs of
 * (run - 1) << 4 | colour), drawn into the canvas in bands of at most 120 rows. */
#include "sloop_logo.h"
static void sloop_logo_draw(uint32_t y0)
{
    uint32_t r0;
    for (r0 = 0; r0 < SLOOP_SPLASH_H; r0 += 120u) {
        uint32_t rows = SLOOP_SPLASH_H - r0 > 120u ? 120u : SLOOP_SPLASH_H - r0;
        uint32_t lo = r0 * SLOOP_SPLASH_W, hi = (r0 + rows) * SLOOP_SPLASH_W, pos = 0, i;
        cv_begin(SLOOP_SPLASH_W, rows, C_BLACK);
        for (i = 0; i < sizeof SLOOP_SPLASH_RLE && pos < hi; i++) {
            uint32_t run = (SLOOP_SPLASH_RLE[i] >> 4) + 1u, c = SLOOP_SPLASH_RLE[i] & 15u, p;
            if (c && pos + run > lo)
                for (p = pos < lo ? lo : pos; p < pos + run && p < hi; p++)
                    cv_px[p - lo] = swap16(SLOOP_SPLASH_PAL[c]);
            pos += run;
        }
        cv_blit((240u - SLOOP_SPLASH_W) / 2u, y0 + r0);
    }
}

/* coreshaw edition: native drawing, no bitmap or reserved upstream icon atlas. */
static void sloop_splash(void)
{
    uint32_t band, x;
    lcd_fill(0, 0, 240, 240, C_BLACK);
    for (band = 0; band < 2; band++) {
        cv_begin(240, 120, RGB(8, 12, 20));
        cv_oy = -(int32_t)(band * 120);
        for (x = 12; x < 240; x += 24) cv_rect(x, 0, 1, 240, RGB(15, 23, 33));
        cv_text(120 - text_w(&FONT_L, "SLOOP") / 2, 25, &FONT_L, "SLOOP", RGB(226, 238, 247));
        cv_text(120 - text_w(&FONT_S, "ALG-02 / CORESHAW EDITION") / 2, 57, &FONT_S,
                "ALG-02 / CORESHAW EDITION", RGB(86, 221, 190));
        for (x = 16; x < 224; x++) {
            int32_t a = (int32_t)(x % 48u), b = (int32_t)(x % 24u);
            int32_t y = 103 + (a < 24 ? a - 12 : 36 - a);
            int32_t z = 103 + (b < 12 ? b - 6 : 18 - b);
            cv_rect((int32_t)x, y, 1, 2, RGB(86, 221, 190));
            cv_rect((int32_t)x, z, 1, 2, RGB(112, 151, 238));
        }
        cv_text(120 - text_w(&FONT_S, "Developed by coreshaw") / 2, 138, &FONT_S,
                "Developed by coreshaw", RGB(226, 238, 247));
        cv_text(120 - text_w(&FONT_S, "github.com/shaw-core/") / 2, 158, &FONT_S,
                "github.com/shaw-core/", RGB(112, 151, 238));
        cv_text(120 - text_w(&FONT_S, "Sloop_ALG02") / 2, 174, &FONT_S, "Sloop_ALG02", RGB(112, 151, 238));
        cv_text(120 - text_w(&FONT_S, "Based on SLOOP + Felucca") / 2, 205, &FONT_S,
                "Based on SLOOP + Felucca", RGB(110, 123, 140));
        cv_oy = 0;
        cv_blit(0, band * 120);
    }
}
