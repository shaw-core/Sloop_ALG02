/* SPDX-License-Identifier: GPL-3.0-only
 * Algorithm-engine extension, 2026. */
/* Eight independently phased sine partials, with spectral focus and stretching.
 * Coefficients are calculated once per control block; no heap or float.
 * Partials taper from 0.375 Fs to zero at 0.4375 Fs, before Nyquist.
 * Shape modulation moves spectral focus. Motion is an independent slow sweep.
 */
#define ADD_NP 8u
typedef struct {
    uint32_t ph[ADD_NP], motion;
    int32_t gain[ADD_NP];
} add_voice_t;
static add_voice_t add_v[NPART][NVOICE];

static add_voice_t *add_state(track_t *t, voice_t *v)
{
    return &add_v[(uint32_t)(t - trk) % NPART][(uint32_t)(v - t->v) % NVOICE];
}

static void additive_note_on(track_t *t, voice_t *v)
{
    add_voice_t *a = add_state(t, v);
    uint32_t k;
    if (v->env_out) return; /* retain phase/gain continuity on retrigger and steal */
    a->motion = (uint32_t)v->note * 2654435761u;
    for (k = 0; k < ADD_NP; k++) {
        a->ph[k] = k * 0x1D000000u;
        a->gain[k] = 0;
    }
}

static void additive_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    add_voice_t *a = add_state(t, v);
    const int16_t *p = t->p;
    uint32_t step[ADD_NP], k, i, count = (uint32_t)p[P_E0];
    int32_t gain[ADD_NP], sum = 0, slope = 32767;
    int32_t focus = p[P_E3] * 14 + (m->shape - 16384) / 16;
    int32_t width = 256 + p[P_E4] * 14;
    int32_t fall = 8192 + p[P_E1] * 193;
    a->motion += LFO_INC[(uint32_t)p[P_E7] & 127u] / 8u;
    focus += sine_i(a->motion) * p[P_E6] / 4096;
    focus = clamp(focus, 0, 7 * 256);
    for (k = 0; k < ADD_NP; k++) {
        uint32_t ratio = (k + 1u) * 256u + (uint32_t)p[P_E5] * k * k / 4u;
        int32_t distance = (int32_t)k * 256 - focus;
        int32_t weight;
        if (distance < 0) distance = -distance;
        weight = clamp(32767 - distance * 32767 / width, 0, 32767);
        weight = mulq15(weight, slope);
        if (k & 1u) weight = weight * p[P_E2] / 127;
        step[k] = 0;
        if (k >= count || m->inc > (0x70000000u / ratio) * 256u) {
            weight = 0;
        } else {
            step[k] = (m->inc >> 8) * ratio;
            if (step[k] > 0x60000000u)
                weight = weight * (int32_t)((0x70000000u - step[k]) >> 16) / 4096;
        }
        gain[k] = weight;
        sum += weight;
        slope = mulq15(slope, fall);
    }
    /* Fixed minimum denominator avoids boosting a nearly vanished partial. */
    if (sum < 8192) sum = 8192;
    for (k = 0; k < ADD_NP; k++) gain[k] = gain[k] * 28000 / sum;
    for (i = 0; i < n; i++) {
        int32_t s = 0;
        for (k = 0; k < ADD_NP; k++) {
            int32_t g = a->gain[k] + (gain[k] - a->gain[k]) * (int32_t)i / CTL;
            if (step[k]) {
                s += mulq15(sine_i(a->ph[k]), g);
                a->ph[k] += step[k];
            }
        }
        out[i] += mulq15(mulq15(s, amp_at(m, i)), VOICE_FS);
    }
    for (k = 0; k < ADD_NP; k++) a->gain[k] = gain[k];
}

static const preset_t ADDITIVE_PRESETS[] = {
    {"PURE",  {1, 100, 127, 0, 127, 0, 0, 20}, {3, 80, 100, 45}, 0, 0, FX(0, 0, 0, 20)},
    {"HOLLOW",{8, 110, 0, 0, 127, 0, 0, 20}, {3, 70, 90, 50}, 0, 0, FX(0, 10, 0, 25)},
    {"PRISM", {8, 118, 110, 28, 100, 0, 22, 30}, {40, 90, 95, 75}, 0, 0, FX(0, 30, 15, 50)},
    {"GLASS", {8, 110, 127, 15, 115, 28, 0, 20}, {0, 98, 0, 85}, 0, 0, FX(0, 0, 20, 55)},
    {"ORBIT", {8, 127, 95, 52, 85, 0, 45, 50}, {50, 100, 100, 80}, 0, 0, FX(0, 20, 25, 45)},
    {"METAL", {6, 123, 127, 0, 127, 70, 0, 20}, {0, 85, 0, 65}, 0, 0, FX(0, 0, 10, 35)},
};
static const engine_t ENG_ADDITIVE = {
    "ADDIT", {"PART", "SPEC"},
    {
        {"PART", F_INT, 1, 8, 8, 0, 0},
        {"TILT", F_PCT, 0, 127, 110, 0, 0},
        {"EVEN", F_PCT, 0, 127, 127, 0, 0},
        {"FOCUS", F_PCT, 0, 127, 0, 0, 0},
        {"WIDTH", F_PCT, 0, 127, 127, 0, 0},
        {"STRET", F_PCT, 0, 127, 0, 0, 0},
        {"MOTION", F_PCT, 0, 127, 0, 0, 0},
        {"SPEED", F_INT, 0, 127, 20, 0, 0},
    },
    ADDITIVE_PRESETS, sizeof(ADDITIVE_PRESETS) / sizeof(ADDITIVE_PRESETS[0]),
    -1, additive_note_on, additive_render, 0xA55F, {P_E1, P_E3, P_E5, P_E6}, 4,
};
