/* SPDX-License-Identifier: Apache-2.0
 * Copyright 2012 Google Inc.
 * C adaptation for the FM-1, 2026. Algorithm routing and envelope model adapted
 * from music-synthesizer-for-android (fm_core.cc, env.cc, dx7note.cc, patch.cc).
 * Apache-2.0 license and provenance are retained in docs/DX7_PROVENANCE.md.
 * This implementation is format-compatible, not a bit-exact Yamaha emulator.
 */
#define DX_POLY 2u
static const uint8_t DX_ALG[32][6] = {
 {0xc1,0x11,0x11,0x14,0x01,0x14},{0x01,0x11,0x11,0x14,0xc1,0x14},
 {0xc1,0x11,0x14,0x01,0x11,0x14},{0x41,0x11,0x94,0x01,0x11,0x14},
 {0xc1,0x14,0x01,0x14,0x01,0x14},{0x41,0x94,0x01,0x14,0x01,0x14},
 {0xc1,0x11,0x05,0x14,0x01,0x14},{0x01,0x11,0xc5,0x14,0x01,0x14},
 {0x01,0x11,0x05,0x14,0xc1,0x14},{0x01,0x05,0x14,0xc1,0x11,0x14},
 {0xc1,0x05,0x14,0x01,0x11,0x14},{0x01,0x05,0x05,0x14,0xc1,0x14},
 {0xc1,0x05,0x05,0x14,0x01,0x14},{0xc1,0x05,0x11,0x14,0x01,0x14},
 {0x01,0x05,0x11,0x14,0xc1,0x14},{0xc1,0x11,0x02,0x25,0x05,0x14},
 {0x01,0x11,0x02,0x25,0xc5,0x14},{0x01,0x11,0x11,0xc5,0x05,0x14},
 {0xc1,0x14,0x14,0x01,0x11,0x14},{0x01,0x05,0x14,0xc1,0x14,0x14},
 {0x01,0x14,0x14,0xc1,0x14,0x14},{0xc1,0x14,0x14,0x14,0x01,0x14},
 {0xc1,0x14,0x14,0x01,0x14,0x04},{0xc1,0x14,0x14,0x14,0x04,0x04},
 {0xc1,0x14,0x14,0x04,0x04,0x04},{0xc1,0x05,0x14,0x01,0x14,0x04},
 {0x01,0x05,0x14,0xc1,0x14,0x04},{0x04,0xc1,0x11,0x14,0x01,0x14},
 {0xc1,0x14,0x01,0x14,0x04,0x04},{0x04,0xc1,0x11,0x14,0x04,0x04},
 {0xc1,0x14,0x04,0x04,0x04,0x04},{0xc4,0x04,0x04,0x04,0x04,0x04}
};
typedef struct { uint32_t phase; int32_t level, gain, prevgain; uint8_t stage, down; } dx_op_t;
typedef struct { dx_op_t op[6]; int32_t fb[2], pitchenv, lfo; uint32_t age, lfophase, lfodelay; uint8_t pstage, pdown, rand; } dx_voice_t;
static const uint8_t DX_P_RATE[100] = {
  1, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12,
  12, 13, 13, 14, 14, 15, 16, 16, 17, 18, 18, 19, 20, 21, 22, 23, 24,
  25, 26, 27, 28, 30, 31, 33, 34, 36, 37, 38, 39, 41, 42, 44, 46, 47,
  49, 51, 53, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 79, 82,
  85, 88, 91, 94, 98, 102, 106, 110, 115, 120, 125, 130, 135, 141, 147,
  153, 159, 165, 171, 178, 185, 193, 202, 211, 232, 243, 254, 255
};
static const int8_t DX_P_LEVEL[100] = {
  -128, -116, -104, -95, -85, -76, -68, -61, -56, -52, -49, -46, -43,
  -41, -39, -37, -35, -33, -32, -31, -30, -29, -28, -27, -26, -25, -24,
  -23, -22, -21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10,
  -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
  28, 29, 30, 31, 32, 33, 34, 35, 38, 40, 43, 46, 49, 53, 58, 65, 73,
  82, 92, 103, 115, 127
};

static dx_voice_t dx_v[NPART][DX_POLY];
static dx_voice_t *dx_state(track_t *t, voice_t *v) {
 return &dx_v[(uint32_t)(t-trk)%NPART][(uint32_t)(v-t->v)%DX_POLY];
}
static int32_t dx_scale(uint32_t value) {
 static const uint8_t lut[20]={0,5,9,13,17,20,23,25,27,29,31,33,35,37,39,41,42,43,45,46};
 value=value>99?99:value; return value>=20?28+(int32_t)value:lut[value];
}
static void dx7_factory(track_t *t, uint32_t pi) {
 uint32_t j; memset(t->xpatch,0,128);
 for(j=0;j<6;j++) {
  uint8_t *o=t->xpatch+j*17; o[0]=95; o[1]=65; o[2]=45; o[3]=75;
  o[4]=99; o[5]=75; o[6]=65; o[7]=0; o[8]=39; o[12]=7<<3;
  o[14]=pi?85: (j==5?99: j==4?72:0); o[15]=(uint8_t)((pi?j+1: j==4?2:1)<<1);
 }
 t->xpatch[102]=t->xpatch[103]=t->xpatch[104]=t->xpatch[105]=99;
 for(j=106;j<110;j++)t->xpatch[j]=50;
 t->xpatch[112]=35; t->xpatch[116]=9;
 t->xpatch[110]=pi?31:4; t->xpatch[111]=8; t->xpatch[117]=24;
 memcpy(t->xpatch+118,pi?"SIX SINES ":"FM KEYS   ",10);
 if(pi==0) { /* electric piano: three two-operator stacks, quieter high harmonics */
  for(j=0;j<6;j++) {uint8_t *o=t->xpatch+j*17;
   o[0]=96;o[1]=j%2?68:76;o[2]=j%2?34:50;o[3]=72;
   o[4]=99;o[5]=j%2?78:56;o[6]=j%2?45:0;o[7]=0;
   o[14]=j%2?96:62;o[15]=(uint8_t)((j<2?1:j<4?1:j%2?1:14)<<1);
   o[16]=j%2?0:2;o[12]=(uint8_t)((j<2?7:j<4?6:8)<<3);
  }
  t->xpatch[110]=4;memcpy(t->xpatch+118,"FM EPIANO ",10);
 } else if(pi==2) {
  for(j=0;j<6;j++){uint8_t *o=t->xpatch+j*17;o[14]=j==5?99:j==4?76:0;o[15]=(j==4?1:1)<<1;o[0]=99;o[1]=75;o[2]=45;o[3]=85;o[4]=99;o[5]=j==5?75:45;o[6]=j==5?65:0;}
  t->xpatch[110]=4;t->xpatch[111]=10;memcpy(t->xpatch+118,"FM BASS   ",10);
 } else if(pi==3) {
  for(j=0;j<6;j++){uint8_t *o=t->xpatch+j*17;o[14]=j%2?96:70;o[15]=(j%2?1:j<2?7:j<4?11:15)<<1;o[16]=j%2?0:28;o[0]=99;o[1]=45;o[2]=32;o[3]=50;o[4]=99;o[5]=50;o[6]=0;}
  t->xpatch[110]=4;t->xpatch[111]=8;memcpy(t->xpatch+118,"FM BELL   ",10);
 }
 t->p[P_E0]=t->xpatch[110]+1; t->p[P_E1]=t->xpatch[111]&7;
 t->p[P_E3]=t->xpatch[112];t->p[P_E4]=t->xpatch[114];t->p[P_E5]=t->xpatch[115];t->p[P_E6]=t->xpatch[117];
}
static void dx7_export(const track_t *t,uint8_t *out) {
 memcpy(out,t->xpatch,128);
 out[110]=(uint8_t)(t->p[P_E0]-1);out[111]=(out[111]&8)|(uint8_t)t->p[P_E1];
 out[112]=(uint8_t)t->p[P_E3];out[114]=(uint8_t)t->p[P_E4];out[115]=(uint8_t)t->p[P_E5];out[117]=(uint8_t)t->p[P_E6];
}
static void dx7_note_on(track_t *t,voice_t *v) {
 dx_voice_t *s=dx_state(t,v); uint32_t j;
 s->age=0; s->fb[0]=s->fb[1]=0;
 s->pitchenv=DX_P_LEVEL[clamp(t->xpatch[109],0,99)]*524288;
 s->pstage=0; s->pdown=1; s->lfodelay=0;
 if(t->xpatch[116]&1) s->lfophase=0x7fffffffu;
 for(j=0;j<6;j++) {
  if(t->xpatch[111]&8) s->op[j].phase=0;
  s->op[j].level=0; s->op[j].stage=0; s->op[j].down=1;
  s->op[j].gain=s->op[j].prevgain=0;
 }
}
static int32_t dx7_amp(track_t *t,voice_t *v) {
 dx_voice_t *s=dx_state(t,v); uint32_t j, alive=0;
 uint32_t unit=(uint32_t)((uint64_t)CTL*25190424u/FS), speed=(uint32_t)clamp(t->p[P_E3],0,99);
 uint32_t sr=speed?(165u*speed)>>6:1u, delta, phase;
 int32_t lfade=32767;
 sr*=sr<160u?11u:11u+((sr-160u)>>4);delta=unit*sr;phase=s->lfophase+=delta;
 switch((t->xpatch[116]>>1)&7u) {
 case 0: s->lfo=(int32_t)(phase>>16);if(phase&0x80000000u)s->lfo=65535-s->lfo;s->lfo=s->lfo*2-32768;break;
 case 1:s->lfo=(int32_t)((~phase^0x80000000u)>>16)-32768;break;
 case 2:s->lfo=(int32_t)((phase^0x80000000u)>>16)-32768;break;
 case 3:s->lfo=phase&0x80000000u?-32768:32767;break;
 case 4:s->lfo=sine_i(phase);break;
 case 5:if(phase<delta)s->rand=(uint8_t)(s->rand*179u+17u);s->lfo=(int32_t)s->rand*256-32768;break;
 default:s->lfo=0;break;
 }
 if(t->xpatch[113]) {
  uint32_t a=99u-(uint32_t)clamp(t->xpatch[113],0,99), inc, d;
  a=(16u+(a&15u))<<(1u+(a>>4));
  inc=unit*(s->lfodelay<0x80000000u?a:((a&0xff80u)>128u?(a&0xff80u):128u));
  d=s->lfodelay+inc;
  if(d>=s->lfodelay) {s->lfodelay=d;lfade=d<0x80000000u?0:(int32_t)((d>>16)&32767u);}
 }
 s->lfo=mulq15(s->lfo,lfade);
 if(!v->gate && s->pdown){s->pdown=0;s->pstage=3;s->age=0;}
 if(s->pstage<3u || (!s->pdown&&s->pstage<4u)) {
  int32_t target=DX_P_LEVEL[clamp(t->xpatch[106+s->pstage],0,99)]*524288;
  int32_t amount=DX_P_RATE[clamp(t->xpatch[102+s->pstage],0,99)]*(int32_t)((uint64_t)CTL*167772160u/(213u*FS));
  if(target>s->pitchenv){s->pitchenv+=amount;if(s->pitchenv>=target){s->pitchenv=target;s->pstage++;}}
  else {s->pitchenv-=amount;if(s->pitchenv<=target){s->pitchenv=target;s->pstage++;}}
 }
 for(j=0;j<6;j++) {
  dx_op_t *e=&s->op[j]; const uint8_t *o=t->xpatch+j*17;
  int32_t ol=dx_scale(o[14]); int32_t vel= (int32_t)v->vel-100;
  int32_t offset=(int32_t)v->note-(int32_t)o[8]-17;
  uint32_t curve=(o[11]>>(offset>=0?2:0))&3;
  int32_t depth=o[offset>=0?10:9], group=(offset<0?-offset:offset)/3;
  int32_t scaling=group*depth*329/4096;
  if(curve==1||curve==2) scaling=scaling*group/12;
  ol=clamp(ol+(curve<2?-scaling:scaling),0,127);
  ol=clamp(ol*32+vel*((o[13]>>2)&7)*2,0,4064);
  if(!v->gate && e->down) { e->down=0; e->stage=3; }
  e->prevgain=e->gain;
  if(e->stage<3 || (e->stage<4&&!e->down)) {
   int32_t target=((dx_scale(o[4+e->stage])>>1)*64+ol-4256);
   int32_t rate=(o[e->stage]*41)>>6;
   int32_t amount;
   target=clamp(target,16,4096)*65536;
   rate=clamp(rate+((o[12]&7)*clamp(v->note/3-7,0,31)>>3),0,63);
   amount=(4+(rate&3))<<(2+CTL_LOG2+(rate>>2)); /* control block is CTL samples */
   if(target>e->level) {
    if(e->level<1716*65536)e->level=1716*65536;
    e->level+=((17*16777216-e->level)>>24)*amount;
    if(e->level>=target){e->level=target;e->stage++;}
   } else {e->level-=amount;if(e->level<=target){e->level=target;e->stage++;}}
  }
  { int32_t pitch=(int32_t)(((int64_t)e->level-14LL*16777216)*192/16777216);
    e->gain=pitch<-3072?0:(int32_t)(pow2_q16(clamp(pitch,-3072,0))>>1); }
  { static const int32_t amsens[4]={0,8481,14006,32767};
    int32_t am=mulq15((s->lfo+32768)/2,(int32_t)t->p[P_E5]*331);
    e->gain=mulq15(e->gain,32767-mulq15(am,amsens[o[13]&3])); }
  if(!(t->p[P_E7]&(1<<(5-j))))e->gain=0;
  if(e->gain>8 && (DX_ALG[(t->p[P_E0]-1)&31][j]&3)==0)alive=1;
 }
 s->age++;
 if(!v->gate && (!alive || s->age>FS/CTL*120u)) {v->active=0;v->stage=0;v->env=0;return 0;}
 return 32767;
}
static void dx7_render(track_t *t,voice_t *v,int32_t *out,uint32_t n,const vmod_t *m) {
 dx_voice_t *s=dx_state(t,v); uint32_t inc[6],j,i,carriers=0;
 const uint8_t *alg=DX_ALG[(t->p[P_E0]-1)&31];
 for(j=0;j<6;j++) {
  const uint8_t *o=t->xpatch+j*17;uint32_t coarse=(o[15]>>1)&31,fine=o[16]>99?99:o[16];
  int32_t det=(int32_t)(o[12]>>3)-7,trans=(int32_t)t->p[P_E6]-24;
  uint64_t freq;
  static const uint8_t pms[8]={0,10,20,33,55,92,153,255};
  int32_t pm=(int32_t)((int64_t)s->lfo*(int32_t)t->p[P_E4]*pms[(t->xpatch[116]>>4)&7]/(32768*99));
  int32_t offset=clamp(trans*16+pm+(int32_t)((int64_t)s->pitchenv*192/16777216),-2304,2304);
  uint64_t base=(uint64_t)m->inc*pow2_q16(offset)/65536u;
  if(o[15]&1) {
   /* Fixed frequency: 10^(coarse%4 + fine/100), Hz, table ratio via 2^x. */
   int32_t d=(int32_t)(((coarse&3)*100+fine)*638/100);
   freq=(uint64_t)97392u*pow2_q16(d)/65536u;
  } else freq=(uint64_t)base*(coarse?coarse*2:1)*(100+fine)/200;
  freq=freq*(uint32_t)clamp(4096+det*5,4000,4200)/4096u;
  inc[j]=(uint32_t)(freq>0x70000000u?0x70000000u:freq);
  if((alg[j]&3)==0)carriers++;
 }
 for(i=0;i<n;i++) {
  int32_t bus[3]={0,0,0},feedback=s->fb[0];
  for(j=0;j<6;j++) {
   uint32_t flags=alg[j],ib=(flags>>4)&3,ob=flags&3;
   int32_t pm=ib?bus[ib]:0, gain=s->op[j].prevgain+(s->op[j].gain-s->op[j].prevgain)*(int32_t)(i+1)/(int32_t)n;
   int32_t y;
   if(flags&0x40)pm+=t->p[P_E1]? (s->fb[0]+s->fb[1])>>(9-t->p[P_E1]):0;
   if(ob) gain=mulq15(gain,clamp(16384+t->p[P_E2]*256,0,48896));
   y=mulq15(sine_i(s->op[j].phase+(uint32_t)pm*131072u),gain);
   s->op[j].phase+=inc[j];
   if(flags&0x80)feedback=y;
   if(flags&4)bus[ob]+=y;else bus[ob]=y;
  }
  s->fb[1]=s->fb[0];s->fb[0]=feedback;
  out[i]+=mulq15(mulq15(bus[0]/(int32_t)(carriers?carriers:1),amp_at(m,i)),VOICE_FS);
 }
}
static const preset_t DX_PRESETS[]={
 {"FM EPIANO",{5,0,64,0,0,0,0,63},{0,127,127,100},0,0,FX(0,0,10,30)},
 {"SIX SINES",{32,0,64,35,0,0,24,63},{0,127,127,100},0,0,FX(0,0,0,25)},
 {"FM BASS",{5,2,64,35,0,0,24,63},{0,127,127,100},0,0,FX(0,0,0,10)},
 {"FM BELL",{5,0,64,35,0,0,24,63},{0,127,127,100},0,0,FX(0,0,8,35)}
};
static const engine_t ENG_DX7={"DX7",{"FM","CTRL"},{
 {"ALG",F_INT,1,32,5,0,0},{"FB",F_INT,0,7,0,0,0},{"BRIGHT",F_PCT,0,127,64,0,0},
 {"LFO",F_INT,0,99,35,0,0},{"PMD",F_INT,0,99,0,0,0},{"AMD",F_INT,0,99,0,0,0},
 {"TRANS",F_INT,0,48,24,0,0},{"OPS",F_INT,0,63,63,0,0}},DX_PRESETS,4,-1,
 dx7_note_on,dx7_render,0x9DBF,{P_E0,P_E1,P_E2,P_REV},DX_POLY};
