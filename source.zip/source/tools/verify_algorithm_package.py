#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Validate ALG02 container checksums, decrypt application and compare build bytes.
Uses Python's CRC implementation rather than the package writer's CRC routine.
Does not validate that the device can boot or execute the resulting program.
"""
import binascii, hashlib, json, struct, sys
from pathlib import Path

def crc(b): return binascii.crc_hqx(b, 0)
def decrypt(b, key=0xffff):
    out=bytearray(b)
    for i in range(len(out)):
        out[i] ^= key & 255
        key=((key<<1) ^ (0x1021 if key&0x8000 else 0)) & 65535
    return out

def entry(b):
    h, d, off, size, flags, reserved, index, name=struct.unpack('<HHIIBBH16s', b)
    assert crc(b[2:])==h, 'JLFS header CRC'
    return d,off,size,flags,name.split(b'\0')[0]

root=Path(__file__).resolve().parents[1]
p=Path(sys.argv[1]) if len(sys.argv)>1 else root/'build/felucca.fwsc'
a=root/'build/felucca.bin'
r=p.read_bytes()
product=''.join(chr((r[i*48+47]-i-1)&255) for i in range(20) if r[i*48+47]!=0x7d)
l=b''.join(r[i*48:i*48+47] for i in range(20))+r[960:]
h=decrypt(l[:64]); hc,lc,total,n=struct.unpack_from('<HHIH',h)
assert crc(h[2:])==hc and total==len(l)
assert crc(l[64:64+n*80])==lc
files={}
for i in range(n):
    e=decrypt(l[64+i*80:144+i*80])
    _,_,c,_,o,s,_=struct.unpack_from('<HHHHIII',e)
    b=l[o:o+s]; assert len(b)==s and crc(b)==c
    files[bytes(e[64:]).split(b'\0')[0].decode()]=b
f=files['flash.bin']
fh=decrypt(f[:32]); assert crc(fh[2:])==struct.unpack_from('<H',fh)[0]
for off in (32,64,96,128):
    c,o,s,flags,name=entry(decrypt(f[off:off+32]))
    if not flags&0x10 and flags!=0x81: assert crc(f[o:o+s])==c
area=bytearray()
for i in range(0,len(f)-0x4000,32):
    area+=decrypt(f[0x4000+i:0x4000+i+32],0x980f^(i>>2))
c,ep,block,_,_=entry(area[:32]); assert crc(area[32:block])==c
c,o,s,_,_=entry(area[32:64]); app=bytes(area[o:o+s])
assert crc(app)==c
compiled=a.read_bytes()
assert app[:len(compiled)]==compiled and all(x==255 for x in app[len(compiled):])
assert product=='FM-1_982' and b'SLOOP ALG02 BANK TEST' in compiled
print(json.dumps(dict(product=product,package_bytes=len(r),app_bytes=len(compiled),
    package_sha256=hashlib.sha256(r).hexdigest(),app_sha256=hashlib.sha256(compiled).hexdigest(),
    container_and_app_crc=True,app_matches_build=True,padding_ff=True,entry_point=hex(ep),
    hardware_tested=False,legacy_unpacker_limitation='jl-misctools boot-bank decoder rejects this SDK SPL; not used as a pass criterion'),indent=2))
