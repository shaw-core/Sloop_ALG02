/* SPDX-License-Identifier: GPL-3.0-only */
/* Direct engine stress test. No MCU accesses; also compiled with ASan/UBSan. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "felucca_tables.h"
#include "../firmware/src/core.h"
#include "../firmware/src/dsp.c"
#include "../firmware/src/eng_pluck.c"
#include "../firmware/src/eng_additive.c"

static void setup(const engine_t *e, track_t *t, voice_t *v, int note, int preset)
{
    unsigned k;
    memset(t, 0, sizeof(*t));
    for (k = 0; k < 8; ++k) t->p[P_E0 + k] = e->presets[preset].e[k];
    v->note = note;
    v->active = v->gate = 1;
    e->note_on(t, v);
}

static vmod_t mod(int note)
{
    vmod_t m = {0};
    m.inc = PITCH_INC[note * 16];
    m.pitch16 = note * 16;
    m.amp0 = m.amp1 = m.envq15 = 24000;
    m.shape = 16384;
    return m;
}

int main(int argc, char **argv)
{
    const engine_t *eng[] = {&ENG_PLUCK, &ENG_ADDITIVE};
    int ei, note, mode, pi, k, block, peak = 0;
    unsigned cases = 0;
    { /* A cold render can occur while the framework transitions engines. */
        track_t *t = &trk[0]; voice_t *v = &t->v[0];
        vmod_t m = mod(69); int32_t out[CTL] = {0};
        setup(&ENG_PLUCK, t, v, 69, 0);
        memset(ks_v, 0, sizeof ks_v);
        ENG_PLUCK.render(t, v, out, CTL, &m);
        for (k = 0; k < CTL; ++k) assert(abs(out[k]) < 40000);
    }
    for (ei = 0; ei < 2; ++ei) {
        const engine_t *e = eng[ei];
        for (pi = 0; pi < e->npresets; ++pi)
            for (k = 0; k < 8; ++k)
                assert(e->presets[pi].e[k] >= e->edit[k].min && e->presets[pi].e[k] <= e->edit[k].max);
        for (note = 0; note < 128; ++note) {
            for (mode = 0; mode < 4; ++mode) {
                track_t *t = &trk[note % NPART];
                voice_t *v = &t->v[note % KS_POLY];
                vmod_t m = mod(note);
                setup(e, t, v, note, note % e->npresets);
                for (k = 0; k < 8; ++k) {
                    if (mode == 1) t->p[P_E0 + k] = e->edit[k].min;
                    if (mode == 2) t->p[P_E0 + k] = e->edit[k].max;
                }
                for (block = 0; block < 200; ++block) {
                    int32_t out[CTL] = {0};
                    if (mode == 3) {
                        k = block % 8;
                        t->p[P_E0 + k] = (block & 1) ? e->edit[k].min : e->edit[k].max;
                        m.inc = PITCH_INC[((note + block) % 128) * 16];
                        m.shape = (block & 1) ? -40000 : 70000;
                    }
                    if (block == 99) e->note_on(t, v);
                    e->render(t, v, out, CTL, &m);
                    for (k = 0; k < CTL; ++k) {
                        assert(out[k] > -40000 && out[k] < 40000);
                        if (abs(out[k]) > peak) peak = abs(out[k]);
                    }
                }
                m.amp0 = m.amp1 = 0;
                { int32_t out[CTL] = {0};
                  e->render(t, v, out, CTL, &m);
                  for (k = 0; k < CTL; ++k) assert(out[k] == 0); }
                ++cases;
            }
        }
    }
    if (argc > 1) {
        for (ei = 0; ei < 2; ++ei) {
            char path[512];
            track_t *t = &trk[0]; voice_t *v = &t->v[0];
            vmod_t m = mod(69);
            setup(eng[ei], t, v, 69, 0);
            if (ei == 0) {
                t->p[P_E0] = 127; t->p[P_E1] = 20; t->p[P_E2] = 1;
                t->p[P_E4] = t->p[P_E5] = 0; t->p[P_E6] = 127;
            }
            snprintf(path, sizeof(path), "%s/%s_A4.raw", argv[1], eng[ei]->name);
            FILE *f = fopen(path, "wb"); assert(f);
            for (block = 0; block < FS / CTL; ++block) {
                int32_t out[CTL] = {0};
                eng[ei]->render(t, v, out, CTL, &m);
                assert(fwrite(out, sizeof(*out), CTL, f) == CTL);
            }
            fclose(f);
        }
    }
    printf("PASS: %u pitch/parameter scenarios, 128 MIDI notes, 12 presets, retrigger, modulation, silence; peak=%d\n", cases, peak);
    return 0;
}
