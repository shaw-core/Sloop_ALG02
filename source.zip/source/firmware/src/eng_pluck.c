/* SPDX-License-Identifier: GPL-3.0-only
 * Algorithm-engine extension, 2026. */
/* Fractional-delay Karplus-Strong string. Four voices per part, fixed buffers.
 * Slow strings update at Fs/2, Fs/4 or Fs/8 so MIDI 0 fits without allocating memory.
 * The divisor is selected at excitation; a glide outside that buffer's range
 * is clamped. Ordinary note-ons cover all MIDI pitches. High notes decay fast
 * because interpolation and the loop low-pass absorb their upper spectrum.
 */
#define KS_POLY 4u
#define KS_LEN 1024u
#define KS_MASK (KS_LEN - 1u)
/* Keep SLOOP punch-in buffers: one part in pool, two in normal RAM. */
static int16_t ks_pool[KS_POLY][KS_LEN] __attribute__((section(".pool")));
static int16_t ks_buf[NPART - 1u][KS_POLY][KS_LEN];
typedef struct {
    uint32_t write, div, tick, init, phase, fade;
    int32_t last, prev, lp, old, current, tail;
} ks_voice_t;
static ks_voice_t ks_v[NPART][KS_POLY];
static const char *const KS_EXC[] = {"NOISE", "PICK", "SOFT"};

static void pluck_note_on(track_t *t, voice_t *v)
{
    ks_voice_t *s = &ks_v[(uint32_t)(t - trk) % NPART][(uint32_t)(v - t->v) % KS_POLY];
    s->init = 1;
}

static void pluck_render(track_t *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m)
{
    uint32_t part = (uint32_t)(t - trk) % NPART, vi = (uint32_t)(v - t->v) % KS_POLY;
    ks_voice_t *s = &ks_v[part][vi];
    int16_t *buf = part ? ks_buf[part - 1u][vi] : ks_pool[vi];
    const int16_t *p = t->p;
    uint32_t full = 0xFFFFFFFFu / (m->inc >> 8 ? m->inc >> 8 : 1u);
    uint32_t delay, whole, frac, i;
    int32_t damp = clamp(p[P_E1] * 128 - (m->shape - 16384) / 4, 0, 16256);
    int32_t feedback, tone = 1024 + p[P_E6] * 246;
    if (s->init || !s->div) {
        int32_t rng = (int32_t)(0x6D2B79F5u ^ ((uint32_t)v->note + 1u) * 2654435761u ^ (uint32_t)p[P_E7] * 1013904223u);
        int32_t mean = 0, smooth = 0;
        uint32_t period;
        if (!rng) rng = 1;
        s->div = 1u;
        while (s->div < 8u && full / s->div > (KS_LEN - 2u) * 256u) s->div *= 2u;
        period = full / s->div / 256u;
        if (period < 2u) period = 2u;
        for (i = 0; i < KS_LEN; i++) {
            int32_t x = (int32_t)(noise32(&rng) >> 16) - 32768;
            if (p[P_E2] == 1) {
                uint32_t pos = i % period, peak = 1u + (period - 2u) * (uint32_t)p[P_E3] / 127u;
                x = pos < peak ? -20000 + (int32_t)(40000u * pos / peak)
                               : 20000 - (int32_t)(40000u * (pos - peak) / (period - peak));
            } else if (p[P_E2] == 2) {
                smooth += (x - smooth) / 4;
                x = smooth;
            }
            buf[i] = (int16_t)(x / 2);
            mean += buf[i];
        }
        mean /= (int32_t)KS_LEN;
        for (i = 0; i < KS_LEN; i++) buf[i] = (int16_t)(buf[i] - mean);
        s->tail = s->last;
        s->fade = 64;
        s->write = s->tick = s->phase = 0;
        s->prev = s->lp = s->old = s->current = 0;
        s->init = 0;
    }
    delay = (uint32_t)clamp((int32_t)(full / s->div) - damp / 128, 256, (KS_LEN - 2u) * 256);
    whole = delay >> 8;
    frac = delay & 255u;
    feedback = 32768 - (int32_t)(((full >> 8) * 5127u) / (120u + (uint32_t)p[P_E0] * (uint32_t)p[P_E0] / 2u));
    feedback = clamp(feedback, 0, 32760);
    for (i = 0; i < n; i++) {
        int32_t x, y;
        if (s->tick == 0) {
            uint32_t a = (s->write - whole) & KS_MASK;
            int32_t read = (buf[a] * (int32_t)(256u - frac) + buf[(a - 1u) & KS_MASK] * (int32_t)frac) / 256;
            int32_t filtered = (read * (32768 - damp) + s->prev * damp) / 32768;
            s->prev = read;
            buf[s->write] = (int16_t)(filtered * feedback / 32768);
            s->write = (s->write + 1u) & KS_MASK;
            s->old = s->current;
            s->current = read;
        }
        x = s->old + (s->current - s->old) * (int32_t)(s->tick + 1u) / (int32_t)s->div;
        s->tick = (s->tick + 1u) % s->div;
        s->phase += m->inc;
        x += mulq15(sine_i(s->phase), p[P_E4] * 64);
        if (p[P_E5]) x = softclip(x * (128 + p[P_E5] * 3) / 128);
        s->lp += (x - s->lp) * tone / 32768;
        x = s->lp;
        if (s->fade) {
            x = (s->tail * (int32_t)s->fade + x * (int32_t)(64u - s->fade)) / 64;
            s->fade--;
        }
        s->last = x;
        y = mulq15(mulq15(x, amp_at(m, i)), VOICE_FS);
        out[i] += y;
    }
}

static const preset_t PLUCK_PRESETS[] = {
    {"NYLON", {100, 85, 0, 50, 10, 0, 105, 1}, {0, 127, 127, 65}, 0, 0, FX(0, 0, 10, 35)},
    {"STEEL", {115, 15, 0, 35, 0, 0, 127, 2}, {0, 127, 127, 70}, 0, 0, FX(0, 10, 15, 35)},
    {"HARP", {110, 50, 1, 30, 0, 0, 115, 3}, {0, 127, 127, 80}, 0, 0, FX(0, 0, 20, 50)},
    {"MUTED", {35, 115, 2, 64, 5, 0, 70, 4}, {0, 85, 0, 45}, 0, 0, FX(0, 0, 0, 20)},
    {"WIRE", {120, 5, 1, 15, 0, 55, 120, 5}, {0, 127, 127, 75}, 0, 0, FX(0, 0, 25, 40)},
    {"BASS", {105, 100, 2, 64, 35, 10, 90, 6}, {0, 100, 70, 50}, 0, 1, FX(0, 0, 0, 15)},
};
static const engine_t ENG_PLUCK = {
    "PLUCK", {"STR", "BODY"},
    {
        {"DECAY", F_PCT, 0, 127, 100, 0, 0},
        {"DAMP", F_PCT, 0, 127, 70, 0, 0},
        {"EXCIT", F_ENUM, 0, 2, 0, KS_EXC, 0},
        {"PICK", F_PCT, 0, 127, 50, 0, 0},
        {"BODY", F_PCT, 0, 127, 0, 0, 0},
        {"DRIVE", F_PCT, 0, 127, 0, 0, 0},
        {"TONE", F_PCT, 0, 127, 110, 0, 0},
        {"SEED", F_INT, 0, 127, 1, 0, 0},
    },
    PLUCK_PRESETS, sizeof(PLUCK_PRESETS) / sizeof(PLUCK_PRESETS[0]),
    -1, pluck_note_on, pluck_render, 0xFDC0, {P_E0, P_E1, P_E3, P_REL}, KS_POLY,
};
